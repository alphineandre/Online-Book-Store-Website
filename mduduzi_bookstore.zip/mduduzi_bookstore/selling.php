<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

if(isset($_POST['add_to_cart'])){

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_POST['product_image'];
   $product_quantity = $_POST['product_quantity'];

   $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

   if(mysqli_num_rows($check_cart_numbers) > 0){
      $message[] = 'already added to cart!';
   }else{
      mysqli_query($conn, "INSERT INTO `cart`(user_id, name, price, quantity, image) VALUES('$user_id', '$product_name', '$product_price', '$product_quantity', '$product_image')") or die('query failed');
      $message[] = 'product added to cart!';
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>sell</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>sell books</h3>
   <p> <a href="home.php">home</a> / sell </p>
</div>

<main id="main" class="">
<div id="content" class="content-area page-wrapper" role="main">
	<div class="row row-main">
		<div class="large-12 col">
			<div class="col-inner">
				
				
														
						
	<section class="section" id="section_1528935676">
		<div class="bg section-bg fill bg-fill bg-loaded">

			
			
			

		</div>

		

		<div class="section-content relative">
			

	<div id="gap-1539551771" class="gap-element clearfix" style="display:block; height:auto;">
		
<style>
#gap-1539551771 {
  padding-top: 30px;
}
</style>
	</div>
	

<div class="row" id="row-683381667">


	<div id="col-945659963" class="col small-11 large-12">
				<div class="col-inner">
			
			

<h1 class="blue-titles" style="text-align: center; max-width: 500px !important;">Sell us your books / Buy used books</h1>
<p>&nbsp;</p>
<h3 style="text-align: center; padding-bottom: 15px;"><strong>How it works</strong></h3>
<ol>
<li style="font-weight: 400;"><span style="font-weight: 400;">Search for the book(s) you want to sell us on our site.&nbsp; Confirm that it is / they are listed on our site.&nbsp; While our stocklist is not exhaustive, we are currently only purchasing books we list on the site.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Complete the ‘Sell us your copy of this book’ link </span><span style="font-weight: 400;">with all required information</span><span style="font-weight: 400;"> on each product page below the ‘Add to Cart” button.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">We will be in contact within 48 hours.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">We will send a courier to collect the book(s).</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">We will currently only purchase books in the following condition:</span>
<ol>
<li style="font-weight: 400;"><b>As New (AN)</b><span style="font-weight: 400;">&nbsp;means that the book is in the state that it would have been in when it left the bookshop / supplier.</span></li>
<li style="font-weight: 400;"><b>Fine</b><span style="font-weight: 400;">&nbsp;</span><b>(F)</b><span style="font-weight: 400;"> is “as new” but allowing for the normal effects of time on a book that has been used. A fine book shows no damage, pen, pencil, highlighter marks, marks of any nature and has no missing content.</span></li>
<li style="font-weight: 400;"><b>Very good</b><span style="font-weight: 400;">&nbsp;</span><b>(VG)</b><span style="font-weight: 400;"> describes a book that is worn but untorn.&nbsp; Some pen, pencil or highlighter marks but no missing content.</span></li>
</ol>
</li>
<li style="font-weight: 400;"><span style="font-weight: 400;">Our decision regarding the condition of the book(s) when received is final and should books we collect not be in the above condition, the seller will have to collect them within seven days.</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;">We will pay you </span><b>40% of the selling price on www.technicalbooks.co.za</b><span style="font-weight: 400;"> at the time of our purchase of your book(s), thirty days after we collect your book(s)&nbsp;<strong>OR&nbsp;</strong></span><span style="font-weight: 400;">We will credit you </span><b>50% of the selling price on www.technicalbooks.co.za</b><span style="font-weight: 400;"> at the time of our purchase of your book(s), seven days after we collect your book(s), against your next order.</span></li>
<li><span style="font-weight: 400;">Ensure you understand the condition of the used book you purchase before completing your transaction as they are not returnable based on their condition. </span></li>
</ol>

		</div>
				
<style>
#col-945659963 > .col-inner {
  padding: 0px 0px 0px 30px;
}
</style>
	</div>

	

</div>

		</div>

		
<style>
#section_1528935676 {
  padding-top: 0px;
  padding-bottom: 0px;
  background-color: rgb(255, 255, 255);
}
#section_1528935676 .ux-shape-divider--top svg {
  height: 150px;
  --divider-top-width: 100%;
}
#section_1528935676 .ux-shape-divider--bottom svg {
  height: 150px;
  --divider-width: 100%;
}
</style>
	</section>
	

<div class="techn-after-content" id="techn-1492242211"><p><span style="color: #fffcfc;"><a style="color: #fffcfc;" href="https://digiartia.com/product/green-lms-the-library-management-system/">https://digiartia.com/product/green-lms-the-library-management-system/</a></span></p>
<p><span style="color: #fffcfc;"><a style="color: #fffcfc;" href="https://digiartia.com/product/document-library-pro/">https://digiartia.com/product/document-library-pro/</a></span></p>
<p><span style="color: #fffcfc;"><a style="color: #fffcfc;" href="https://digiartia.com/product/wp-sheet-editor-media-library/">https://digiartia.com/product/wp-sheet-editor-media-library/</a></span></p>
<p>&nbsp;</p>
</div>
						
												</div>
		</div>
	</div>
</div>


</main>
<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>
    
</body>
</html>    
<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>about us</h3>
   <p> <a href="home.php">home</a> / about </p>
</div>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="images/about-img.jpg" alt="">
      </div>

      <div class="content">
         <h3>why choose us?</h3>
         <p>Our store was created with the basis of assisting students get their books easily and at low prices thus giving them fully control over their education 
          and allowing them to not be slowed down by not having enough money to pay for their books.</p>
         <p>We also provide tutors that are trained to assist student with problems and educate them on things they do not understand.</p>
         <a href="contact.php" class="btn">contact us</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="title">client's reviews</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/girl no 1.jpeg" alt="">
         <p>Quick delivery and supporting independent book stores - that's pretty        important.
             Downside - there isn't generally much in the way of book descriptions / reviews so I tend to do that on "that other site" and then purchase from Mduduzi BookStore</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Angel</h3>
      </div>

      <div class="box">
         <img src="images/girl no 2.jpeg" alt="">
         <p>I used Mduduzi BookStore already many times and I was always 100% satisfied. Our cities and towns would be so much sadder places if the last Mduduzi bookstores were to disappear, so if I can't make it to them I shop with Mduduzi BookStore. It is a win win. I love Mduduzi BookStore!</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Mia</h3>
      </div>

      <div class="box">
         <img src="images/guy no 1.jpeg" alt="">
         <p>I purchased from Mduduzi BookStore because I want to give small independent shops my support but don't want to drive to them. This is the best of both worlds. Really impressed with both the efficiency of the delivery, and the sensible amount of packaging. Will definitely be using again.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>John</h3>
      </div>

      <div class="box">
         <img src="images/guy no 2.jpeg" alt="">
         <p>As ever, the books were delivered within a couple of days, except the ones they had told me would be later, and all packed well and in great condition.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Leon</h3>
      </div>

      <div class="box">
         <img src="images/guy no 3.jpeg" alt="">
         <p>I ordered a book which was not clearly labelled and was not what I expected. After writing this in a review the bookshop were very helpful and remedied the situation with a full refund</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Alex</h3>
      </div>

      <div class="box">
         <img src="images/girl 3.jpeg" alt="">
         <p>I found the book I wanted really easily and it arrived within a day or two. I paid a bit more (but not much) than I would have done if I’d bought it from Amazon but I’m happy to do that to support independent bookshops. I’ll definitely use Mduduzi BookStore again.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Ashley</h3>
      </div>

   </div>

</section>









<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>